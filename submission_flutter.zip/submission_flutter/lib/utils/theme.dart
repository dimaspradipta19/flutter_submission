import 'package:flutter/material.dart';

const Color redColor = Color(0xFFEF3024);
const Color blackColor = Color(0xFF3E3E3E);
const Color greyColor = Color(0xFF7B7B7B);
const Color backgroundColor = Color(0xFFF3F3F9);
const Color whiteColor = Color(0xFFD2D2D2);
const Color whiteColor2 = Color(0xFFFFFFFF);